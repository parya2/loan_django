
from django.shortcuts import render, redirect
from .models import Loan, Payment
from django.utils import timezone

def loan_list(request):
    loans = Loan.objects.all()
    return render(request, 'loanapp/loan_list.html', {'loans': loans})

def add_loan(request):
    if request.method == 'POST':
        Loan.objects.create(
            name=request.POST['name'],
            amount=request.POST['amount'],
            interest_rate=request.POST['interest_rate'],
            start_date=request.POST['start_date'],
            end_date=request.POST['end_date']
        )
        return redirect('loan_list')
    return render(request, 'loanapp/add_loan.html')

def add_payment(request, loan_id):
    loan = Loan.objects.get(id=loan_id)
    if request.method == 'POST':
        Payment.objects.create(
            loan=loan,
            date=request.POST['date'],
            amount=request.POST['amount']
        )
        return redirect('loan_list')
    return render(request, 'loanapp/add_payment.html', {'loan': loan})
