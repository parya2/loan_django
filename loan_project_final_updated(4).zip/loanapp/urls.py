
from django.urls import path
from . import views

urlpatterns = [
    path('', views.loan_list, name='loan_list'),
    path('add_loan/', views.add_loan, name='add_loan'),
    path('add_payment/<int:loan_id>/', views.add_payment, name='add_payment'),
]
